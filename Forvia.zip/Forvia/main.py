import streamlit as st

st.set_page_config(
    page_title= "Dashboard multi página",
    layout = "wide",
    initial_sidebar_state = "expanded" #collapsed
)

#definir paginas
home_page= st.Page(
    "Paginas/home.py",
    title="Home",
    #icon = ":material​/menu:"
)

projects_page= st.Page(
    "Paginas/projects.py",
    title="Análsis de Projectos"
)

percentage_page= st.Page(
    "Paginas/percentage.py",
    title="Análsis de Porcentajes"
)

#navegación
pg= st.navigation([home_page, projects_page, percentage_page])

pg=st.navigation({
    "Inicio": [home_page],
    "Análsis":[projects_page, percentage_page]
    })

#ejectutar
pg.run()